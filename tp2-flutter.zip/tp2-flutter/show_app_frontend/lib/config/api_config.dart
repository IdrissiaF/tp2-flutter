class ApiConfig {
  static const String baseUrl = "http://10.0.2.2:5000"; // pour Android Emulator
  // Pour navigateur Chrome via Flutter Web : utilise localhost
  // static const String baseUrl = "http://localhost:5000";
}
