package com.example.show_app_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
